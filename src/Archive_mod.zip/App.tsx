import { useState } from 'react'
import logo from './logo.svg'
import './App.css'

function App() {
  const [username, setUsername] = useState('')

  return (
    <div className="loginBox">
      <form action="">
      <h1 className='title'>Bem-vindo</h1>
      <p className='description'>Portal do Lojista, para acessar insira seus dados.</p>
      <label htmlFor="">
      Usuário
      </label>
      <input type="text"  id="username" value="rafael" placeholder='Digite seu usuário' autoComplete='false' />
      <label htmlFor="">
      Senha
      </label>
      <input type="password"  id="password" value="rafael" placeholder='Digite sua senha' autoComplete='false' />
      <small>Esqueceu sua senha? <a href='#'>clique aqui</a>
</small>
      <button>Entrar</button>
      </form>
    </div>
  )
}

export default App
